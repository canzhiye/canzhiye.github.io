# nba-draft-adages
---
### adages to analyze
- skinny bigs bust more often, or take longer to develop
- 4 year college players have less upside, less potential
- above average length translates to above average defense
- the Spurs generally do well in the draft
- undersized PGs something something
